var app = angular.module("myapp", ["ngRoute"]);
/*app.config(['$locationProvider', function($locationProvider) {
	$locationProvider.hashPrefix('');
}]);*/
app.config(['$routeProvider', '$locationProvider', function($routeProvider, $locationProvider) {
//	$locationProvider.html5Mode(true);
//	$locationProvider.hashPrefix('');
    $routeProvider
    .when("/", {
        templateUrl : "./html/aboutUs.html"
    })
    .when("/diversity", {
        templateUrl : "./html/vmServices.html",
        controller : "vmServicesCtrl",
//        reloadOnSearch: false
    })
    .when("/media", {
        templateUrl : "./html/staffingSolutions.html",
        controller : "staffingSolutionsCtrl"
    })
    .when("/register", {
        templateUrl : "./html/registration.html",
        controller : "registrationCtrl"
    })
    .when("/contactus", {
        templateUrl : "./html/training.html",
        controller : "trainingCtrl"
    })
    .otherwise({
    	templateUrl : "./html/aboutUs.html"
    });
}]);

app.controller("menuController", function($scope) {
	$scope.offeringsMenu = [{name:"VENDOR MANAGED SERVICES", value:"#vmServices"},
	                  {name:"STAFFING SOLUTIONS", value:"#staffingSolutions"},
	                  {name:"STRATEGIC IT PARTNER", value:"#strategicPartner"},
	                  {name:"TRAINING", value:"#training"}];
	$scope.technologiesMenu = [{name:"WEB SERVICES", value:"#webServices"},
	                  {name:"DATABASE MANAGEMENT", value:"#dbManagement"},
	                  {name:"ERP", value:"#erp"},
	                  {name:"CRM", value:"#crm"},
	                  {name:"QUALITY ASSURANCE", value:"#qualityAssurance"}];
	/*$scope.productsMenu = [{name:"eBridge Tester", value:"#ebridgeTester"},
	     	                  {name:"eBridge Tracker", value:"#ebridgeTracker"},
	     	                  {name:"eBridge Handler", value:"#ebridgeHandler"}];*/
});

/***Offerings controllers Starts***/
app.controller("vmServicesCtrl", function($scope) {
	$scope.msg = "Welcome to vmService Controller";
	$scope.servicesList = [{name:"Vendor Managed Services", value:"#vmServices", activeClass:"btn-primary round", animationClass:""},
	                       {name:"Staffing Solutions", value:"#staffingSolutions", activeClass:"btn-secondary", animationClass:"faa-parent animated-hover"},
	                       {name:"Strategic IT Partner", value:"#strategicPartner", activeClass:"btn-secondary", animationClass:"faa-parent animated-hover"},
	                       {name:"Training", value:"#training", activeClass:"btn-secondary", animationClass:"faa-parent animated-hover"}];
});

app.controller("staffingSolutionsCtrl", function($scope) {
	$scope.msg = "Welcome to staffing solutions";
	$scope.servicesList = [{name:"Vendor Managed Services", value:"#vmServices", activeClass:"btn-secondary", animationClass:"faa-parent animated-hover"},
	                       {name:"Staffing Solutions", value:"#staffingSolutions", activeClass:"btn-primary round", animationClass:""},
	                       {name:"Strategic IT Partner", value:"#strategicPartner", activeClass:"btn-secondary", animationClass:"faa-parent animated-hover"},
	                       {name:"Training", value:"#training", activeClass:"btn-secondary", animationClass:"faa-parent animated-hover"}];
});

app.controller("registrationCtrl", function($scope, $http) {
	$scope.msg = "Welcome to Registration page";
	/*$scope.servicesList = [{name:"Vendor Managed Services", value:"#vmServices", activeClass:"btn-secondary", animationClass:"faa-parent animated-hover"},
	                       {name:"Staffing Solutions", value:"#staffingSolutions", activeClass:"btn-secondary", animationClass:"faa-parent animated-hover"},
	                       {name:"Strategic IT Partner", value:"#strategicPartner", activeClass:"btn-primary round", animationClass:""},
	                       {name:"Training", value:"#training", activeClass:"btn-secondary", animationClass:"faa-parent animated-hover"}];*/
	
	$http({
	    url: "http://lifeofengineers.com/JanaSenani/rest/datadisplay/listvvtdata",
	    dataType: "json",
	    method: "GET",
	    headers: {
//	    	"Access-Control-Allow-Origin": "*",
	        "Content-Type": "application/json"
	    }
//	    data: {'user_name':'anchu.venki@gmail.com', 'password': 'venkat'}
	}).then(function successCallback(response) {
    	console.log("test");
    	console.log(response.data.statesData);
    	//var states = response.data.statesData; var districts = states[0].districtsInfos; districts[0];
    	}, function errorCallback(response) {
    		console.log("failed");
    });
});

app.controller("contactusCtrl", function($scope) {
	$scope.msg = "Welcome to training";
	$scope.servicesList = [{name:"Vendor Managed Services", value:"#vmServices", activeClass:"btn-secondary", animationClass:"faa-parent animated-hover"},
	                       {name:"Staffing Solutions", value:"#staffingSolutions", activeClass:"btn-secondary", animationClass:"faa-parent animated-hover"},
	                       {name:"Strategic IT Partner", value:"#strategicPartner", activeClass:"btn-secondary", animationClass:"faa-parent animated-hover"},
	                       {name:"Training", value:"#training", activeClass:"btn-primary round", animationClass:""}];
});
/***Offerings controllers Ends***/

$('.button-checkbox').each(function () {

        // Settings
        var $widget = $(this),
            $button = $widget.find('button'),
            $checkbox = $widget.find('input:checkbox'),
            color = $button.data('color'),
            settings = {
                on: {
                    icon: 'glyphicon glyphicon-check'
                },
                off: {
                    icon: 'glyphicon glyphicon-unchecked'
                }
            };

        // Event Handlers
        $button.on('click', function () {
            $checkbox.prop('checked', !$checkbox.is(':checked'));
            $checkbox.triggerHandler('change');
            updateDisplay();
        });
        $checkbox.on('change', function () {
            updateDisplay();
        });

        // Actions
        function updateDisplay() {
            var isChecked = $checkbox.is(':checked');

            // Set the button's state
            $button.data('state', (isChecked) ? "on" : "off");

            // Set the button's icon
            $button.find('.state-icon')
                .removeClass()
                .addClass('state-icon ' + settings[$button.data('state')].icon);

            // Update the button's color
            if (isChecked) {
                $button
                    .removeClass('btn-default')
                    .addClass('btn-' + color + ' active');
            }
            else {
                $button
                    .removeClass('btn-' + color + ' active')
                    .addClass('btn-default');
            }
        }

        // Initialization
        function init() {

            updateDisplay();

            // Inject the icon if applicable
            if ($button.find('.state-icon').length == 0) {
                $button.prepend('<i class="state-icon ' + settings[$button.data('state')].icon + '"></i>');
            }
        }
        init();
    });
